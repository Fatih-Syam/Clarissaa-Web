# Clarissaa-Web 💙

Sebuah website romantis sederhana untuk seseorang spesial bernama **Shandana Clarissa Auliavera**.

> “I'm drawn to you and chasing after you not just because I like you,  
> but because there's something in you that makes me wanna grow.  
> You feel like someone a few steps ahead of me—bukan dengan cara yang bikin aku minder yaa,  
> tapi justru bikin aku pengen kejar itu.  
> Thank you, Shandana Clarissa Auliavera. I’m truly happy to know you.”  
>
> — S.F.

Website ini berisi animasi salju, tombol lucu, dan pesan singkat penuh makna.  
Dibuat dengan Next.js + TailwindCSS, dan di-host di Vercel.